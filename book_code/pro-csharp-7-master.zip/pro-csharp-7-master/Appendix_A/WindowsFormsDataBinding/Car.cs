﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsDataBinding
{
	public class Car
	{
		public int Id { get; set; }
		public string PetName { get; set; }
		public string Make { get; set; }
		public string Color { get; set; }

	}
}
